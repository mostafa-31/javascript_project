<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3D Calculator</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #222;
            font-family: Arial, sans-serif;
        }
        .calculator {
            width: 300px;
            background: #333;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        #display {
            width: 100%;
            height: 50px;
            font-size: 1.5em;
            text-align: right;
            padding-left: 0px;
            padding-right: 0px;
            padding-bottom: 10px;
            padding-top: 10px;
            border: none;
            background: #444;
            color: white;
            border-radius: 5px;
            outline: none;
        }
        .buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin-top: 15px;
        }
        button {
            height: 60px;
            font-size: 1.2em;
            border: none;
            background: linear-gradient(145deg, #444, #222);
            color: white;
            border-radius: 5px;
            box-shadow: 4px 4px 10px rgba(0, 0, 0, 0.5);
            transition: all 0.2s;
            cursor: pointer;
        }
        button:hover {
            background: linear-gradient(145deg, #555, #333);
            transform: translateY(-3px);
            box-shadow: 6px 6px 12px rgba(0, 0, 0, 0.7);
        }
        button:active {
            transform: translateY(1px);
        }
        .operator {
            color: #21f503;
        }
        .special {
            color: rgb(245, 120, 3);
        }
        .clear {
            color: rgb(245, 3, 3);
        }
        .sqrt {
            color: rgb(245, 59, 3);
        }
    </style>
</head>
<body>
    <div class="calculator">
        <input type="text" id="display" disabled>
        <div class="buttons">
            <button onclick="playSound(); clearAll()" class="special">AC</button>
            <button onclick="playSound(); clearLast()" class="clear">CLR</button>
            <button onclick="playSound(); appendSymbol('^')" class="operator">x^x</button>
            <button onclick="playSound(); appendSymbol('/')" class="operator">/</button>
            
            <button onclick="playSound(); appendSymbol('7')">7</button>
            <button onclick="playSound(); appendSymbol('8')">8</button>
            <button onclick="playSound(); appendSymbol('9')">9</button>
            <button onclick="playSound(); appendSymbol('*')" class="operator">X</button>
            
            <button onclick="playSound(); appendSymbol('4')">4</button>
            <button onclick="playSound(); appendSymbol('5')">5</button>
            <button onclick="playSound(); appendSymbol('6')">6</button>
            <button onclick="playSound(); appendSymbol('-')" class="operator">-</button>
            
            <button onclick="playSound(); appendSymbol('1')">1</button>
            <button onclick="playSound(); appendSymbol('2')">2</button>
            <button onclick="playSound(); appendSymbol('3')">3</button>
            <button onclick="playSound(); appendSymbol('+')" class="operator">+</button>
            
            <button onclick="playSound(); appendSymbol('0')">0</button>
            <button onclick="playSound(); appendSymbol('.')">.</button>
            <button onclick="playSound(); appendSymbol('√')" class="sqrt">√</button>
            <button onclick="playSound(); calculateResult()" class="operator">=</button>

            <!-- Added bracket buttons -->
            <button onclick="playSound(); appendSymbol('(')" class="operator">(</button>
            <button onclick="playSound(); appendSymbol(')')" class="operator">)</button>
            
            <!-- Added Log and e buttons -->
            <button onclick="playSound(); appendSymbol('log(')" class="operator">log</button>
            <button onclick="playSound(); appendSymbol('e^')" class="operator">e^</button>
        </div>
    </div>
    <script>
        function appendSymbol(symbol) {
            document.getElementById('display').value += symbol;
        }

        function clearAll() {
            document.getElementById('display').value = '';
        }

        function clearLast() {
            let display = document.getElementById('display');
            display.value = display.value.slice(0, -1);
        }

        function calculateResult() {
            let display = document.getElementById('display').value;

            // Handling square root calculations
            if (display.includes('√')) {
                let parts = display.split('√');
                if (parts[1] !== '') {
                    display = Math.sqrt(parseFloat(parts[1]));
                } else {
                    display = 'Error';
                }
            }

            // Handling log calculations with a user-defined base
            if (display.includes('log(')) {
                let parts = display.split('log(');
                if (parts[1] && parts[1].includes(')')) {
                    let logValue = parts[1].split(')')[0];
                    let base = parseFloat(prompt('Enter base for logarithm:', '10')); // Prompt for base
                    if (base > 0 && base !== 1) {
                        display = Math.log(parseFloat(logValue)) / Math.log(base);
                    } else {
                        display = 'Error';
                    }
                } else {
                    display = 'Error';
                }
            }

            // Handling exponential calculations with e^x
            if (display.includes('e^')) {
                let parts = display.split('e^');
                if (parts[1]) {
                    display = Math.exp(parseFloat(parts[1]));
                } else {
                    display = 'Error';
                }
            }

            // Handling general calculations (including powers)
            else {
                try {
                    display = eval(display.replace('^', '**'));
                } catch (error) {
                    display = 'Error';
                }
            }

            document.getElementById('display').value = display;
        }

        function playSound() {
            let audio = new Audio('click2.mp3'); // Make sure the sound file is in the same directory
            audio.play();
        }
    </script>
</body>
</html>
